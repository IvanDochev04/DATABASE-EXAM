﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=DESKTOP-1TMBS98;Database=VaporStore;Trusted_Connection=True";
	}
}